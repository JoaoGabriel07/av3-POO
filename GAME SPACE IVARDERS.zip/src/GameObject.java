import java.awt.*;

public class GameObject {
    public GameObject(int x, int y) {
    }

    protected Rectangle getBounds(int larguraInimigo, int alturaInimigo) {
        Rectangle o = null;
        return o;
    }
}
